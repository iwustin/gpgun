# AI Work

import os
import subprocess
import tempfile
import shutil

input_folder = "."

def convert_ogg(file_path):
    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as temp_file:
        temp_path = temp_file.name
    
    cmd = [
        "ffmpeg",
        "-i", file_path,
        "-c:a", "libvorbis",
        "-ac", "1",
        "-ar", "44100",
        "-y",
        temp_path
    ]
    
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            shutil.move(temp_path, file_path)
            print(f"Успешно перекодирован и заменён: {file_path}")
            return True
        else:
            print(f"Ошибка при перекодировке {file_path}: {result.stderr}")
            os.remove(temp_path)
            return False
    except Exception as e:
        print(f"Исключение при перекодировке {file_path}: {str(e)}")
        if os.path.exists(temp_path):
            os.remove(temp_path)
        return False

def process_folder(folder_path):
    successful = 0
    failed = 0
    
    for entry in os.listdir(folder_path):
        entry_path = os.path.join(folder_path, entry)
        
        if os.path.isfile(entry_path) and entry.lower().endswith(".ogg"):
            if convert_ogg(entry_path):
                successful += 1
            else:
                failed += 1
        
        elif os.path.isdir(entry_path):
            print(f"Обработка папки: {entry_path}")
            sub_success, sub_failed = process_folder(entry_path)
            successful += sub_success
            failed += sub_failed
    
    return successful, failed

def main():
    if not os.path.exists(input_folder):
        print(f"Папка {input_folder} не найдена")
        return
    
    print(f"Начало обработки папки: {input_folder}")
    successful, failed = process_folder(input_folder)
    
    print(f"\nОбработка завершена:")
    print(f"Успешно перекодировано и заменено: {successful} файлов")
    print(f"Не удалось обработать: {failed} файлов")

if __name__ == "__main__":
    main()
